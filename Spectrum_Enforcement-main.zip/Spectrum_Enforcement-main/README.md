# Spectrum_Enforcement

1) For Running the simulation code:


$make

$./simul

Note: Different volunteer selection algorithm functions (or combinations of it) need to be called for the different experiments. 
 
2) For generating plots:

$cd python_code_for_plots

$python plot_acc.py

$python plot_hr.py

$python plot_happy.py

Note: The input data in the .py files need to be changed for generating the plots of the different experiments. 


