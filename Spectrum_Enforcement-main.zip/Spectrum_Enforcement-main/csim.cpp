g++ -DCPP -Ilib $* lib/csim.cpp.a -lm
