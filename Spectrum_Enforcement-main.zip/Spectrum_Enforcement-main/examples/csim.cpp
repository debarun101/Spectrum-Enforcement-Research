g++ -DCPP -I../lib $* ../lib/csim.cpp.a -lm
